//
//  SASlideMenuLeftMenuSegue.h
//  SASlideMenu
//
//  Created by Stefano Antonelli on 1/17/13.
//  Copyright (c) 2013 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SASlideMenuLeftMenuSegue : UIStoryboardSegue

@end
