//
//  SASlideMenuRightMenuSegue.h
//  SASlideMenu
//
//  Created by Stefano Antonelli on 11/25/12.
//  Copyright (c) 2012 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SASlideMenuRightMenuSegue : UIStoryboardSegue

@end
