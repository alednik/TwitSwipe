//
//  SASlideMenuRightMenuViewController.h
//  SASlideMenu
//
//  Created by Stefano Antonelli on 2/5/13.
//  Copyright (c) 2013 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SASlideMenuRootViewController.h"

@interface SASlideMenuRightMenuViewController : UITableViewController

@property(nonatomic,strong) SASlideMenuRootViewController* rootController;

@end
