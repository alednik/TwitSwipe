//
//  ExampleMenuViewController.h
//  SASlideMenu
//
//  Created by Stefano Antonelli on 8/13/12.
//  Copyright (c) 2012 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SASlideMenuViewController.h"
#import "SASlideMenuDataSource.h"
@interface ExampleStaticMenuViewController :SASlideMenuViewController
@end
