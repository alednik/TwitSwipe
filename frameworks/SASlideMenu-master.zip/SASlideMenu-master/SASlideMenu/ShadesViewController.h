//
//  LightViewController.h
//  SASlideMenu
//
//  Created by Stefano Antonelli on 10/26/12.
//  Copyright (c) 2012 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShadesViewController : UIViewController

@property(nonatomic, strong) IBOutlet UIView* tableContainer;

@end
