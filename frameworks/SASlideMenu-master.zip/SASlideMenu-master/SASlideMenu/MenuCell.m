//
//  SASlideMenuCell.m
//  SASlideMenu
//
//  Created by Stefano Antonelli on 8/6/12.
//  Copyright (c) 2012 Stefano Antonelli. All rights reserved.
//

#import "MenuCell.h"

@implementation MenuCell

@synthesize itemDescription;
@synthesize disclosureImage;

-(void) layoutSubviews{
    [super layoutSubviews];
}
@end
