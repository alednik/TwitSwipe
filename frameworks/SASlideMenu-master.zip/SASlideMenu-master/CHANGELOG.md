# CHANGELOG

Version 1.2.0
* Fixed issues #41,#40,#38,#33
* Changes to SASlideMenuDataSource
* SASlideMenuStatic example now cache the content view controllers
* Added CHANGELOG.md

Version 1.2.1
* Fixed issues #47,#52,#53
* added an iPad example in SASlideMenuiPad

