//
//  ExampleDynamicRightMenu.m
//  SASlideMenu
//
//  Created by Stefano Antonelli on 2/5/13.
//  Copyright (c) 2013 Stefano Antonelli. All rights reserved.
//

#import "ExampleDynamicRightMenu.h"

@interface ExampleDynamicRightMenu ()

@end

@implementation ExampleDynamicRightMenu

@end
