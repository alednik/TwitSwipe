//
//  ExampleiPadAppDelegate.h
//  SASlideMenuiPad
//
//  Created by Stefano Antonelli on 3/13/13.
//  Copyright (c) 2013 Stefano Antonelli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleiPadAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
